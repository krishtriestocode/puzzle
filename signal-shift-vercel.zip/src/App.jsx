import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Zap, RotateCcw, Lightbulb, Trophy, Clock3, Move, Volume2, VolumeX, CircleHelp, ArrowUpRight, Check, LockKeyhole } from "lucide-react";

const LEVELS = [
  { name: "Warm-up", size: 4, par: 5, start: 4, end: 11, tiles: [
    {i:0, type:"corner", r:1}, {i:1,type:"straight",r:1}, {i:2,type:"corner",r:2},
    {i:4,type:"straight",r:0}, {i:5,type:"corner",r:0}, {i:6,type:"straight",r:1},
    {i:8,type:"corner",r:0}, {i:9,type:"straight",r:1}, {i:10,type:"corner",r:3},
    {i:12,type:"straight",r:0}, {i:13,type:"corner",r:3}, {i:14,type:"straight",r:0}
  ]},
  { name: "Crossroads", size: 5, par: 9, start: 5, end: 19, tiles: [
    {i:0,type:"corner",r:1},{i:1,type:"straight",r:0},{i:2,type:"corner",r:2},{i:3,type:"straight",r:1},
    {i:5,type:"straight",r:0},{i:6,type:"corner",r:0},{i:7,type:"straight",r:1},{i:8,type:"corner",r:3},
    {i:10,type:"corner",r:0},{i:11,type:"straight",r:1},{i:12,type:"cross",r:0},{i:13,type:"straight",r:1},
    {i:15,type:"straight",r:0},{i:16,type:"corner",r:3},{i:17,type:"straight",r:0},{i:18,type:"corner",r:2},
    {i:20,type:"corner",r:0},{i:21,type:"straight",r:1},{i:22,type:"corner",r:1},{i:23,type:"straight",r:1}
  ]},
  { name: "Overload", size: 5, par: 12, start: 10, end: 14, tiles: [
    {i:0,type:"straight",r:1},{i:1,type:"corner",r:1},{i:2,type:"straight",r:0},{i:3,type:"corner",r:2},{i:4,type:"straight",r:1},
    {i:5,type:"corner",r:0},{i:6,type:"straight",r:1},{i:7,type:"corner",r:3},{i:8,type:"straight",r:0},{i:9,type:"corner",r:0},
    {i:11,type:"straight",r:0},{i:12,type:"cross",r:0},{i:13,type:"straight",r:1},
    {i:15,type:"corner",r:3},{i:16,type:"straight",r:0},{i:17,type:"corner",r:0},{i:18,type:"straight",r:1},{i:19,type:"corner",r:2},
    {i:20,type:"straight",r:1},{i:21,type:"corner",r:2},{i:22,type:"straight",r:0},{i:23,type:"corner",r:3},{i:24,type:"straight",r:1}
  ]}
];

const DIRS = ["N","E","S","W"];
const DELTA = {N:[-1,0], E:[0,1], S:[1,0], W:[0,-1]};
const OPP = {N:"S", E:"W", S:"N", W:"E"};
const basePorts = { straight:["N","S"], corner:["N","E"], cross:["N","E","S","W"] };
const rotatePorts = (type, rotation) => (basePorts[type] || []).map(d => DIRS[(DIRS.indexOf(d)+rotation)%4]);
const initialBoard = (level) => {
  const total = level.size * level.size;
  const board = Array.from({length:total}, (_,i) => ({type:"empty", rotation:0, fixed:false, i}));
  level.tiles.forEach(t => { board[t.i] = {...t, fixed:false}; });
  board[level.start] = {type:"source", rotation:0, fixed:true, i:level.start};
  board[level.end] = {type:"target", rotation:0, fixed:true, i:level.end};
  // Every level is a pipe-rotation puzzle; empty spaces are blockers.
  return board;
};
const portsFor = tile => {
  if (tile.type === "source") return ["E"];
  if (tile.type === "target") return ["W"];
  return rotatePorts(tile.type, tile.rotation);
};
const findPowered = (board, size, start) => {
  const powered = new Set([start]);
  const queue = [start];
  while (queue.length) {
    const idx = queue.shift();
    const tile = board[idx];
    for (const d of portsFor(tile)) {
      const [dr,dc] = DELTA[d], r=Math.floor(idx/size), c=idx%size, nr=r+dr, nc=c+dc;
      if(nr<0||nc<0||nr>=size||nc>=size) continue;
      const ni=nr*size+nc, next=board[ni];
      if(next.type==="empty" || !portsFor(next).includes(OPP[d])) continue;
      if(!powered.has(ni)){powered.add(ni);queue.push(ni);}
    }
  }
  return powered;
};
const makeScramble = (levelIndex) => {
  const level = LEVELS[levelIndex];
  let b = initialBoard(level);
  // The supplied rotations form a scramble. Keep a known simple target path in every board.
  // Player rotates any pipe clockwise; the board checks for a connected source-to-target circuit.
  return b.map((tile, i) => {
    if (tile.type === "straight") return {...tile, rotation: (tile.rotation + (i%2 ? 1:0))%2};
    if (tile.type === "corner") return {...tile, rotation: (tile.rotation + ((i*3+levelIndex)%4))%4};
    return tile;
  });
};

function Pipe({tile, powered, onClick, disabled}) {
  const ports = portsFor(tile);
  const isEnd = tile.type === "source" || tile.type === "target";
  return <button className={`tile ${tile.type} ${powered ? "powered":""} ${tile.type==="empty"?"empty-tile":""} ${isEnd?"terminal":""}`}
    onClick={onClick} disabled={disabled || tile.type==="empty" || isEnd} aria-label={`${tile.type} tile, rotate`}>
    <svg viewBox="0 0 100 100" className="pipe-svg" style={{transform:`rotate(${tile.rotation*90}deg)`}}>
      {tile.type==="source" && <><circle cx="50" cy="50" r="28" className="terminal-ring"/><path d="M24 50 H76" className="pipe-line"/><path d="M59 34 L76 50 L59 66" className="pipe-line"/></>}
      {tile.type==="target" && <><circle cx="50" cy="50" r="28" className="terminal-ring"/><path d="M24 50 H76" className="pipe-line"/><circle cx="50" cy="50" r="8" className="target-dot"/></>}
      {tile.type!=="source" && tile.type!=="target" && tile.type!=="empty" && <>
        <circle cx="50" cy="50" r="13" className="pipe-joint"/>
        {ports.map(p => {
          const end = {N:[50,0],E:[100,50],S:[50,100],W:[0,50]}[p];
          return <line key={p} x1="50" y1="50" x2={end[0]} y2={end[1]} className="pipe-line" />;
        })}
        <circle cx="50" cy="50" r="5" className="pipe-core"/>
      </>}
    </svg>
    {tile.type==="source" && <span className="tile-tag">IN</span>}
    {tile.type==="target" && <span className="tile-tag">OUT</span>}
    {tile.type!=="empty" && !isEnd && <span className="rotate-hint">↻</span>}
  </button>;
}

export default function App() {
  const [levelIndex, setLevelIndex] = useState(0);
  const [board, setBoard] = useState(() => makeScramble(0));
  const [moves, setMoves] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const [running, setRunning] = useState(true);
  const [won, setWon] = useState(false);
  const [hint, setHint] = useState(false);
  const [showHow, setShowHow] = useState(false);
  const [sound, setSound] = useState(true);
  const [best, setBest] = useState(() => {
    try { return JSON.parse(localStorage.getItem("signal-shift-best") || "{}"); } catch { return {}; }
  });
  const level = LEVELS[levelIndex];
  const powered = useMemo(() => findPowered(board, level.size, level.start), [board, level]);
  const connected = powered.has(level.end);
  const elapsed = useMemo(() => `${Math.floor(seconds/60).toString().padStart(2,"0")}:${(seconds%60).toString().padStart(2,"0")}`, [seconds]);

  useEffect(() => {
    if (!running || won) return;
    const id = setInterval(() => setSeconds(s => s + 1), 1000);
    return () => clearInterval(id);
  }, [running, won]);

  useEffect(() => {
    if (connected && !won) {
      setWon(true);
      setRunning(false);
      const next = {...best};
      const old = next[levelIndex];
      if (!old || moves < old.moves) {
        next[levelIndex] = {moves, seconds};
        setBest(next);
        try { localStorage.setItem("signal-shift-best", JSON.stringify(next)); } catch {}
      }
    }
  }, [connected, won, best, levelIndex, moves, seconds]);

  const reset = useCallback((idx=levelIndex) => {
    setLevelIndex(idx); setBoard(makeScramble(idx)); setMoves(0); setSeconds(0);
    setWon(false); setRunning(true); setHint(false);
  }, [levelIndex]);

  const rotate = (idx) => {
    if (won) return;
    setBoard(prev => prev.map((t,i) => i===idx && !t.fixed ? {...t, rotation:(t.rotation+1)%4} : t));
    setMoves(m => m+1);
    setHint(false);
  };

  const useHint = () => {
    if (won) return;
    setHint(true);
    // Hint points to a pipe on the board that can be rotated to make a useful connection.
    const candidate = board.findIndex((t,i) => !t.fixed && t.type!=="empty" && !powered.has(i));
    if (candidate >= 0) {
      setBoard(prev => prev.map((t,i) => i===candidate ? {...t, rotation:(t.rotation+1)%4} : t));
      setMoves(m => m+1);
    }
  };

  useEffect(() => {
    const onKey = (e) => {
      if (e.key.toLowerCase()==="r") reset();
      if (e.key.toLowerCase()==="h") useHint();
      if (e.key==="Escape") setShowHow(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  return <main className="app-shell">
    <div className="ambient ambient-one"></div><div className="ambient ambient-two"></div>
    <header className="topbar">
      <a className="brand" href="#" onClick={e=>e.preventDefault()}><span className="brand-mark"><Zap size={19} fill="currentColor"/></span><span>SIGNAL<span className="brand-light">SHIFT</span></span></a>
      <div className="top-actions">
        <button className="icon-btn" onClick={()=>setShowHow(true)} aria-label="How to play"><CircleHelp size={18}/><span>How to play</span></button>
        <button className="icon-btn sound-btn" onClick={()=>setSound(!sound)} aria-label="Toggle sound">{sound?<Volume2 size={18}/>:<VolumeX size={18}/>}</button>
      </div>
    </header>

    <section className="hero">
      <div className="eyebrow"><span className="live-dot"></span> PUZZLE LAB <span className="eyebrow-divider">/</span> DAILY BRAIN TRAINING</div>
      <h1>Make the <span>connection.</span></h1>
      <p className="hero-copy">Rotate the circuits. Light up the grid. Get the signal from <b>IN</b> to <b>OUT</b>.</p>
    </section>

    <section className="game-layout">
      <aside className="side-panel left-panel">
        <div className="panel-kicker">YOUR MISSION</div>
        <div className="mission-icon"><Zap size={23}/></div>
        <h2>Route the<br/>signal.</h2>
        <p>Every turn changes the path. Find a clean route with as few moves as possible.</p>
        <div className="objective-row"><span className="objective-dot input-dot"></span><span>Signal input</span><span className="objective-line"></span><span className="objective-dot output-dot"></span></div>
        <div className="mini-legend"><div><span className="legend-line"></span> Live connection</div><div><span className="legend-line muted"></span> Unpowered pipe</div></div>
        <button className="text-btn" onClick={()=>setShowHow(true)}>Learn the rules <ArrowUpRight size={15}/></button>
      </aside>

      <section className="board-card">
        <div className="board-top">
          <div><div className="level-label">CURRENT CHALLENGE</div><h2>{String(levelIndex+1).padStart(2,"0")} <span>/</span> {level.name}</h2></div>
          <div className={`status-pill ${connected?"status-live":""}`}><span className="status-dot"></span>{won?"SIGNAL CONNECTED":connected?"SIGNAL CONNECTED":"SIGNAL OFFLINE"}</div>
        </div>
        <div className={`board-grid size-${level.size}`} style={{"--size":level.size}}>
          {board.map((tile,i)=><Pipe key={`${levelIndex}-${i}`} tile={tile} powered={powered.has(i)} onClick={()=>rotate(i)} disabled={won}/>)}
        </div>
        <div className="board-footer">
          <div className="board-note"><span className="tiny-pulse"></span> Tap a pipe to rotate <span className="note-separator">·</span> 90° clockwise</div>
          <button className="reset-btn" onClick={()=>reset()}><RotateCcw size={14}/> Restart</button>
        </div>
        {won && <div className="win-banner"><div className="win-icon"><Check size={20}/></div><div><strong>Signal restored!</strong><span>You cracked {level.name.toLowerCase()} in {moves} moves.</span></div><button onClick={()=>levelIndex<LEVELS.length-1?reset(levelIndex+1):reset(0)}>{levelIndex<LEVELS.length-1?"Next level":"Play again"} <ArrowUpRight size={15}/></button></div>}
      </section>

      <aside className="side-panel right-panel">
        <div className="panel-kicker">RUN STATS</div>
        <div className="stat-block"><div className="stat-label"><Move size={14}/> MOVES</div><div className="stat-number">{String(moves).padStart(2,"0")}<span className="stat-unit">moves</span></div><div className="stat-sub">Par: {level.par} moves</div><div className="progress-track"><div className="progress-fill" style={{width:`${Math.min(100,moves/level.par*100)}%`}}/></div></div>
        <div className="stat-block"><div className="stat-label"><Clock3 size={14}/> TIME ELAPSED</div><div className="stat-number timer">{elapsed}<span className="stat-unit">min:sec</span></div><div className="stat-sub">{won?"Time stopped":"Every second counts"}</div></div>
        <div className="stat-block best-block"><div className="stat-label"><Trophy size={14}/> PERSONAL BEST</div><div className="best-value">{best[levelIndex]?`${best[levelIndex].moves} moves`:"— —"}</div><div className="stat-sub">{best[levelIndex]?`Best time ${Math.floor(best[levelIndex].seconds/60).toString().padStart(2,"0")}:${(best[levelIndex].seconds%60).toString().padStart(2,"0")}`:"Complete a level to set a record"}</div></div>
        <button className="hint-btn" onClick={useHint} disabled={won}><Lightbulb size={17}/> <span>Give me a nudge</span><kbd>H</kbd></button>
        {hint && <p className="hint-message">Try rotating an unpowered pipe so it points toward a live connection.</p>}
      </aside>
    </section>

    <section className="level-section">
      <div className="section-heading"><div><div className="panel-kicker">PICK YOUR CHALLENGE</div><h2>Level select</h2></div><span className="levels-count">{LEVELS.length} LEVELS</span></div>
      <div className="level-cards">
        {LEVELS.map((l,i)=><button key={l.name} className={`level-card ${i===levelIndex?"selected":""} ${i>0&&!best[i-1]&&i>levelIndex?"locked":""}`} onClick={()=>reset(i)}>
          <div className="level-card-top"><span className="level-num">0{i+1}</span>{best[i]?<span className="completed-mark"><Check size={13}/></span>:i>levelIndex?<LockKeyhole size={14}/>:<ArrowUpRight size={15}/>}</div>
          <div className="level-card-name">{l.name}</div><div className="level-card-desc">{l.size} × {l.size} grid <span>·</span> Par {l.par} moves</div>
          <div className="level-card-bottom"><span>{best[i]?`BEST ${best[i].moves} MOVES`:"READY TO PLAY"}</span><span className="card-arrow">↗</span></div>
        </button>)}
      </div>
    </section>

    <footer><div className="footer-brand"><Zap size={14} fill="currentColor"/> SIGNALSHIFT</div><span>Built for curious minds. One connection at a time.</span><span className="footer-key">R <span>restart</span> · H <span>hint</span></span></footer>

    {showHow && <div className="modal-backdrop" onClick={()=>setShowHow(false)}><section className="how-modal" onClick={e=>e.stopPropagation()} role="dialog" aria-modal="true" aria-labelledby="how-title">
      <button className="modal-close" onClick={()=>setShowHow(false)}>×</button><div className="modal-icon"><Zap size={22}/></div><div className="panel-kicker">QUICK START</div><h2 id="how-title">How to play</h2>
      <div className="rule-row"><span>01</span><div><strong>Find the route</strong><p>Connect the green <b>IN</b> tile to the blue <b>OUT</b> tile.</p></div></div>
      <div className="rule-row"><span>02</span><div><strong>Rotate the pipes</strong><p>Tap any pipe to rotate it 90° clockwise. Pipes connect only when their open ends face each other.</p></div></div>
      <div className="rule-row"><span>03</span><div><strong>Use fewer moves</strong><p>Beat the par score, set a personal best, and unlock your puzzle-solving flow.</p></div></div>
      <div className="modal-tip"><Lightbulb size={16}/><span>Shortcut: press <kbd>R</kbd> to restart or <kbd>H</kbd> for a nudge.</span></div>
      <button className="primary-btn" onClick={()=>setShowHow(false)}>Got it, let's play <ArrowUpRight size={16}/></button>
    </section></div>}
  </main>;
}